# Changelog

- v2.0.0 - Second Version
  - Added validation for required fields
  - Improved script to log all possible errors in the BP execution history
