This scenario is necessary to send notifications via Email. 
It enables the automation of the notifications distribution process both to Workgroup members and to manually specified recipients, using pre-configured parameters and templates.

Current version of content pack provides 2 types of Actions:
1. **Email (WG mailing)**: used for sending notifications through a Mailing configured in the Workgroup
2. **Email (custom mailing)**: used if the mailing needs to be specifically targeted to Workgroup members or if recipients are not Monq users and addresses need to be specified manually

## Features

- Sending messages to Email

## Content

This scenario will configure following objects in Workgroup you select:

- **Action Email (WG mailing)**
- **Action Email (custom mailing)**

![localImage](/docs/PNG_en_full_descr_actions-tab.png)

### Available Parameters
#### For Email (WG mailing)
- Mailing: selection one of the existing Mailings in the Workgroup

#### For Email (custom mailing)
- Connection: a space Administrator pre-configured Connection
- Recipients_WG: a list of recipients from current Workgroup members
- Other_Recipients: a list of recipients filled manually or passed as an array of strings from previous Actions, Start events, or Tools

#### Common
- Subject: subject of the email that recipients will see
- Message: mailing template with ability to use in the text variables with data obtained from previous Actions, Start events, or Tools
- MailFormat (Plain/HTML): message format. Plain - simple text without formatting. HTML allows the use of HTML tags for styles, images, and links, making emails visually rich.

![localImage](/docs/PNG_en_full_descr_action-params.png)

## Feedback

Found an error, have a question, or want to suggest a new feature? Contact us through:

- Discussion on the <a href="https://github.com/orgs/MONQDL/discussions" target="_blank">community portal</a>

&nbsp; &nbsp;