After successfully executing scenario, **Email (WG mailing)** and **Email (custom mailing)** actions will appear on the <a href="{{ baseUri }}/pl-b/business-processes?tab=actions" target="_blank">Actions</a> page. After that, they can be added to Canvas Workflow, connected, and configured.

To execute notifications in a prepared Workgroup Mailing, the **Email (WG mailing)** action is suitable. If recipients need to be manually specified or passed as an array of strings from previous Actions, Start events, or Tools - your choice is **Email (custom mailing)**.

## 1. Add the necessary Action to the canvas

![localImage](/docs/PNG_en_post-instr_add-action.png)

## 2.1. If it's Email (WG mailing) - select the Mailing
Dropdown list will display all Mailings, pre-configured by manager of the current Workgroup (<a href="https://docs.monq.ru/docs/get-started/quick-guide/add-mailing-list" target="_blank">help</a>)

## 2.2. If it's Email (custom mailing) - Select "Email" connection

## 2.3. Specify recipients

There are three ways to specify recipients of the mailing:
- in "Recipients_WG" field, you can select members of the current Workgroup
- in "Other_Recipients" field, in the fillable list mode: manually specify email addresses
- in "Other_Recipients" field, in the mode of passing variables: set the string array with email addresses passed as input from previous Actions, Start events, or Tools

## 3. Specify subject of the message

Variables passed into the Action from previous Actions, Start events, or Tools can be used


## 4. Compose text of the message to be sent

Message text can be multiline. Variables passed into the Action from previous Actions, Start events, or Tools can be used in the text.
By default, the Plain message format is set - it is a simple text without formatting.
If you need to make message visually richer and more interactive (styles, links, images, tables, font-formatting), switch MailFormat to `HTML` mode and use HTML tags in the message.

![localImage](/docs/PNG_en_full_descr_action-params.png)

## 5. Save Action settings

## 6. Publish Business Process

Any changes to the Business Process must be finalized by its publication.

&nbsp; &nbsp;

> ⚠️ **Important!** 
>
> Monq Administrator must previously fill in attributes in the corresponding Action type `Email` Connection in Automation settings (<a href="https://docs.monq.ru/docs/get-started/setup/delivery-types" target="_blank">help</a>)
>

&nbsp; &nbsp;