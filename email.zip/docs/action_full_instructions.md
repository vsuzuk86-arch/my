After successful execution of the content pack scenario, some additional configurations in the Monq platform will be required. 
These settings include actions that need to be performed by both Monq Administrator and end-users who are the recipients of mailings.

## What is required from recipients:
Specify actual email address in the settings of their Monq profile (Profile Settings → Contacts → Email)

![localImage](/docs/PNG_en_instr_profile-contact.png)

## What is required from the Monq Workgroup manager:
Configure the Mailing in the Workgroup: specify users and/or Roles of the Workgroup who should receive notifications (<a href="https://docs.monq.ru/docs/get-started/quick-guide/add-mailing-list" target="_blank">help</a>)

![localImage](/docs/PNG_en_instr_wg-mailings.png)

## What is required from Monq Administrator:
**if not done previously*

Fill in attributes in the corresponding Action type `Email` Connection in Automation settings (<a href="https://docs.monq.ru/docs/get-started/setup/delivery-types" target="_blank">help</a>)

![localImage](/docs/PNG_en_instr_action-connection.png)

&nbsp; &nbsp;

> **⚠️ Warning**
>
> The instructions for installation and the API calls to external systems used in the Actions of the content-pack are up-to-date as of the Monq release publication date
>

&nbsp; &nbsp;